import Stripe from 'stripe'
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2024-06-20' })
export const FEE_PERCENT = Number(process.env.PLATFORM_FEE_PERCENT ?? 15)

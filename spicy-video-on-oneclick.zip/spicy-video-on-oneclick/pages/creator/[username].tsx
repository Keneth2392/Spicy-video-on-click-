import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'

export default function Creator(){
  const { query } = useRouter()
  const username = String(query.username ?? 'demo')
  const [price, setPrice] = useState<number>(9.99)
  const [subscribed, setSubscribed] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(()=>{
    (async()=>{
      const res = await fetch(`/api/creator/${username}`)
      if(res.ok){
        const data = await res.json()
        setPrice((data?.price_monthly ?? 999)/100)
      }
      const status = await fetch(`/api/subscription/status?creator=${username}`)
      setSubscribed(status.ok && (await status.json()).active)
    })()
  },[username])

  const subscribe = async () => {
    setLoading(true)
    const res = await fetch('/api/stripe/create-checkout', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ creatorUsername: username })
    })
    const data = await res.json()
    if(data.url) window.location.href = data.url
    else alert('No se pudo crear el checkout.')
    setLoading(false)
  }

  return (<div className="container">
    <div className="card">
      <h2>@{username}</h2>
      <p>Suscripción: <b>${price.toFixed(2)}/mes</b></p>
      {!subscribed ? <button disabled={loading} onClick={subscribe}>{loading?'Abriendo pago…':'Suscribirse'}</button>
                   : <span>✅ Contenido desbloqueado</span>}
    </div>
    <div className="card" style={{position:'relative',marginTop:16}}>
      {!subscribed && <div style={{position:'absolute',inset:0,display:'grid',placeItems:'center',opacity:.15,fontSize:'4vw'}}>SUSCRÍBETE PARA VER</div>}
      <video src="https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" style={{width:'100%',borderRadius:12}} controls={subscribed} muted={!subscribed}/>
    </div>
  </div>)
}
import type { NextApiRequest, NextApiResponse } from 'next'
import { supabase } from '../../../lib/supabase'
// MVP: simula que el usuario fan es "guest"; busca si hay sub activa entre guest y creator
export default async function handler(req:NextApiRequest,res:NextApiResponse){
  const creator = String(req.query.creator)
  const { data } = await supabase.from('subscriptions').select('active,current_period_end').eq('fan_username','guest').eq('creator_username',creator).maybeSingle()
  res.json({ active: Boolean(data?.active && new Date(data.current_period_end||0) > new Date()) })
}

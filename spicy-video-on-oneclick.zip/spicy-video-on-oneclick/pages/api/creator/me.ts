import type { NextApiRequest, NextApiResponse } from 'next'
import { supabaseAdmin } from '../../../lib/supabase'

// MVP: usa un perfil fijo "demo" si no existe
export default async function handler(req:NextApiRequest,res:NextApiResponse){
  const username = 'demo'
  if(req.method==='GET'){
    const { data, error } = await supabaseAdmin.from('profiles').select('*').eq('username',username).single()
    if(error && error.code==='PGRST116'){ // not found
      await supabaseAdmin.from('profiles').insert({ username, is_creator: true, price_monthly: 999 })
      return res.json({ username, is_creator:true, price_monthly:999 })
    }
    return res.json(data ?? { username, is_creator:true, price_monthly:999 })
  }
  if(req.method==='POST'){
    const { username: u, price_monthly } = req.body
    const { data, error } = await supabaseAdmin.from('profiles').upsert({ username: u ?? username, price_monthly, is_creator:true }).select().single()
    if(error) return res.status(400).json({ error: error.message })
    return res.json(data)
  }
  res.status(405).end()
}

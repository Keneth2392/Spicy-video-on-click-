import type { NextApiRequest, NextApiResponse } from 'next'
import { supabase } from '../../../lib/supabase'

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  const { username } = req.query as { username: string }
  const { data, error } = await supabase.from('profiles').select('username,price_monthly,connect_account_id').eq('username', username).single()
  if(error) return res.status(404).json({ error: 'creator_not_found' })
  res.json(data)
}

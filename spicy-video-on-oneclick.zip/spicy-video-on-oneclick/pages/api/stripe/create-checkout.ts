import type { NextApiRequest, NextApiResponse } from 'next'
import { stripe, FEE_PERCENT } from '../../../lib/stripe'
import { supabase } from '../../../lib/supabase'

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  if(req.method!=='POST') return res.status(405).end()
  const { creatorUsername } = req.body as { creatorUsername: string }
  const { data: creator, error } = await supabase.from('profiles').select('*').eq('username', creatorUsername).single()
  if(error || !creator) return res.status(404).json({ error: 'creator_not_found' })
  if(!creator.connect_account_id) return res.status(400).json({ error: 'creator_not_connected' })

  const price = Number(creator.price_monthly ?? 999)

  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [{
      price_data: {
        unit_amount: price,
        currency: 'usd',
        product_data: { name: `Suscripción a @${creatorUsername}` },
        recurring: { interval: 'month' }
      },
      quantity: 1
    }],
    subscription_data: {
      transfer_data: { destination: creator.connect_account_id },
      application_fee_percent: FEE_PERCENT
    },
    customer_creation: 'always',
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/creator/${creatorUsername}?success=1`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/creator/${creatorUsername}?canceled=1`,
  })

  res.json({ url: session.url })
}

import type { NextApiRequest, NextApiResponse } from 'next'
import { stripe } from '../../../../lib/stripe'
import { supabaseAdmin } from '../../../../lib/supabase'

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  if(req.method!=='POST') return res.status(405).end()
  const username = 'demo' // MVP: único creador
  // crea una cuenta connect si no existe
  const { data: profile } = await supabaseAdmin.from('profiles').select('*').eq('username', username).single()
  let acctId = profile?.connect_account_id
  if(!acctId){
    const acct = await stripe.accounts.create({ type: 'express' })
    acctId = acct.id
    await supabaseAdmin.from('profiles').update({ connect_account_id: acctId }).eq('username', username)
  }
  const accountLink = await stripe.accountLinks.create({
    account: acctId!,
    refresh_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
    return_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
    type: 'account_onboarding'
  })
  res.json({ url: accountLink.url })
}

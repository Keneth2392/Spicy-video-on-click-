import type { NextApiRequest, NextApiResponse } from 'next'
import { stripe } from '../../../lib/stripe'
import { supabaseAdmin } from '../../../lib/supabase'
import { buffer } from 'micro'

export const config = { api: { bodyParser: false } }

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  if(req.method!=='POST') return res.status(405).end()
  const sig = req.headers['stripe-signature'] as string
  const buf = await buffer(req)
  let event
  try{
    event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  }catch(e:any){
    return res.status(400).send(`Webhook Error: ${e.message}`)
  }

  if(event.type==='checkout.session.completed'){
    const session = event.data.object as any
    const line = session?.metadata?.creatorUsername
    // En este MVP no usamos metadata; derivamos el creator por la URL de success/cancel si lo desearas.
    // Asumimos @demo
    const creator = 'demo'
    const customerId = session.customer as string
    const subId = session.subscription as string
    // Marca suscripción activa por 30 días
    const current_period_end = new Date(Date.now() + 30*24*3600*1000).toISOString()
    await supabaseAdmin.from('subscriptions').upsert({
      fan_username: 'guest', creator_username: creator,
      stripe_customer_id: customerId, stripe_sub_id: subId,
      active: true, current_period_end
    }, { onConflict: 'fan_username,creator_username' })
  }

  if(event.type==='customer.subscription.deleted'){
    const sub = event.data.object as any
    await supabaseAdmin.from('subscriptions').update({ active:false }).eq('stripe_sub_id', sub.id)
  }
  if(event.type==='customer.subscription.updated'){
    const sub = event.data.object as any
    const active = sub.status==='active' || sub.status==='trialing'
    const end = new Date(sub.current_period_end*1000).toISOString()
    await supabaseAdmin.from('subscriptions').update({ active, current_period_end: end }).eq('stripe_sub_id', sub.id)
  }

  res.json({ received: true })
}

import Link from 'next/link'
export default function Home(){
  return (<div className="container">
    <div className="card">
      <h1>Spicy Video On 🔥</h1>
      <p>MVP con suscripciones y Stripe Connect.</p>
      <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
        <Link href="/dashboard">Ir al Dashboard del Creador</Link>
        <Link href="/creator/demo">Ver perfil de @demo</Link>
      </div>
    </div>
  </div>)
}
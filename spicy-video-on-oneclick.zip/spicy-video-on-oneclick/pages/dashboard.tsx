import { useEffect, useState } from 'react'

export default function Dashboard(){
  const [username,setUsername]=useState('demo')
  const [price,setPrice]=useState(999)
  const [connect,setConnect]=useState<{connected:boolean,url?:string}|null>(null)
  const [saving,setSaving]=useState(false)

  useEffect(()=>{(async()=>{
    const res = await fetch('/api/creator/me')
    if(res.ok){
      const data = await res.json()
      setUsername(data.username??'demo')
      setPrice(data.price_monthly??999)
      setConnect({connected: Boolean(data.connect_account_id)})
    }
  })()},[])

  const save = async ()=>{
    setSaving(true)
    await fetch('/api/creator/me',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,price_monthly:price})})
    setSaving(false)
  }
  const onboard = async ()=>{
    const r = await fetch('/api/stripe/connect/onboard',{method:'POST'})
    const d = await r.json()
    if(d.url) window.location.href=d.url
  }

  return (<div className="container">
    <div className="card">
      <h1>Dashboard del Creador</h1>
      <label>Username</label>
      <input className="input" value={username} onChange={e=>setUsername(e.target.value)}/>
      <label>Precio mensual (centavos)</label>
      <input className="input" type="number" value={price} onChange={e=>setPrice(Number(e.target.value))}/>
      <div style={{display:'flex',gap:8,marginTop:12}}>
        <button onClick={save} disabled={saving}>{saving?'Guardando…':'Guardar'}</button>
        <button onClick={onboard}>{connect?.connected?'Gestionar pagos':'Conectar Stripe (KYC)'}</button>
      </div>
    </div>
  </div>)
}